// application-crud/index.js
const { init } = require('@dieugene/ydb-serverless');
const crypto = require('crypto');

// Проверяем JWT_SECRET, но не требуем его для работы с БД (YDB не зависит от JWT)
const JWT_SECRET = process.env.JWT_SECRET || 'supersecretkey_mfc2025';

// Инициализируем клиент YDB с адресом из переменной окружения
let ydb;
try {
    if (!process.env.YDB_ADDRESS) throw new Error('YDB_ADDRESS env var is required');
    ydb = init(process.env.YDB_ADDRESS);
    console.log('✅ YDB client initialized');
} catch (err) {
    console.error('❌ YDB init failed:', err.message);
    ydb = null;
}

// === Вспомогательные функции ===
function getUserIdFromToken(token) {
    try {
        const parts = token.split('.');
        if (parts.length !== 3) return null;
        const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
        return payload.userId;
    } catch (err) {
        return null;
    }
}

function isAdmin(token) {
    try {
        const parts = token.split('.');
        if (parts.length !== 3) return false;
        const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString());
        return payload.role === 'admin';
    } catch (err) {
        return false;
    }
}

function errorResponse(statusCode, message) {
    return {
        statusCode,
        body: JSON.stringify({ error: message }),
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        }
    };
}

function successResponse(statusCode, data) {
    return {
        statusCode,
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': true
        }
    };
}

// === CRUD операции ===
async function createApplication(body, userId) {
    const { serviceType, personalData, documents = [] } = body;
    if (!serviceType || !personalData) {
        return errorResponse(400, 'Missing required fields: serviceType, personalData');
    }

    const id = crypto.randomUUID();
    const now = Date.now();
    const status = 'draft';

    const query = `
        DECLARE $id AS Utf8;
        DECLARE $user_id AS Utf8;
        DECLARE $service_type AS Utf8;
        DECLARE $status AS Utf8;
        DECLARE $personal_data AS Json;
        DECLARE $documents AS Json;
        DECLARE $created_at AS Uint64;
        DECLARE $updated_at AS Uint64;
        
        UPSERT INTO applications (id, user_id, service_type, status, personal_data, documents, created_at, updated_at)
        VALUES ($id, $user_id, $service_type, $status, $personal_data, $documents, $created_at, $updated_at)
    `;

    await ydb.apply(query, {
        $id: id,
        $user_id: userId,
        $service_type: serviceType,
        $status: status,
        $personal_data: JSON.stringify(personalData),
        $documents: JSON.stringify(documents),
        $created_at: now,
        $updated_at: now
    });

    return successResponse(201, { id, message: 'Application created successfully' });
}

async function getApplications(userId, queryParams) {
    const limit = Math.min(parseInt(queryParams.limit) || 20, 100);
    const offset = (parseInt(queryParams.page) - 1) * limit || 0;

    let sql = `
        DECLARE $user_id AS Utf8;
        DECLARE $limit AS Uint64;
        DECLARE $offset AS Uint64;
        
        SELECT id, user_id, service_type, status, personal_data, documents, created_at, updated_at
        FROM applications
        WHERE user_id = $user_id
        ORDER BY created_at DESC
        LIMIT $limit OFFSET $offset
    `;

    const results = await ydb.execute(sql, {
        $user_id: userId,
        $limit: limit,
        $offset: offset
    });

    const items = results.map(row => ({
        id: row.id,
        userId: row.user_id,
        serviceType: row.service_type,
        status: row.status,
        personalData: JSON.parse(row.personal_data),
        documents: JSON.parse(row.documents),
        createdAt: new Date(Number(row.created_at)).toISOString(),
        updatedAt: new Date(Number(row.updated_at)).toISOString()
    }));

    return successResponse(200, { items, total: items.length });
}

async function getApplicationById(applicationId, userId, isAdminUser) {
    const query = `
        DECLARE $id AS Utf8;
        SELECT id, user_id, service_type, status, personal_data, documents, created_at, updated_at
        FROM applications
        WHERE id = $id
    `;

    const results = await ydb.execute(query, { $id: applicationId });

    if (results.length === 0) {
        return errorResponse(404, 'Application not found');
    }

    const app = results[0];
    // Проверка прав: владелец или админ
    if (!isAdminUser && app.user_id !== userId) {
        return errorResponse(403, 'Access denied');
    }

    return successResponse(200, {
        id: app.id,
        userId: app.user_id,
        serviceType: app.service_type,
        status: app.status,
        personalData: JSON.parse(app.personal_data),
        documents: JSON.parse(app.documents),
        createdAt: new Date(Number(app.created_at)).toISOString(),
        updatedAt: new Date(Number(app.updated_at)).toISOString()
    });
}

async function updateApplication(applicationId, body, userId, isAdminUser) {
    const { status, personalData, documents } = body;
    const now = Date.now();

    // Проверяем существование заявки
    const checkQuery = `
        DECLARE $id AS Utf8;
        SELECT user_id FROM applications WHERE id = $id
    `;
    const checkResult = await ydb.execute(checkQuery, { $id: applicationId });

    if (checkResult.length === 0) {
        return errorResponse(404, 'Application not found');
    }

    if (!isAdminUser && checkResult[0].user_id !== userId) {
        return errorResponse(403, 'Access denied');
    }

    const updates = [];
    const params = { $id: applicationId, $updated_at: now };

    if (status !== undefined) {
        updates.push('status = $status');
        params.$status = status;
    }
    if (personalData !== undefined) {
        updates.push('personal_data = $personal_data');
        params.$personal_data = JSON.stringify(personalData);
    }
    if (documents !== undefined) {
        updates.push('documents = $documents');
        params.$documents = JSON.stringify(documents);
    }

    if (updates.length === 0) {
        return errorResponse(400, 'No fields to update');
    }

    const query = `
        DECLARE $id AS Utf8;
        DECLARE $updated_at AS Uint64;
        ${status !== undefined ? 'DECLARE $status AS Utf8;' : ''}
        ${personalData !== undefined ? 'DECLARE $personal_data AS Json;' : ''}
        ${documents !== undefined ? 'DECLARE $documents AS Json;' : ''}
        
        UPDATE applications
        SET ${updates.join(', ')}, updated_at = $updated_at
        WHERE id = $id
    `;

    await ydb.apply(query, params);
    return successResponse(200, { message: 'Application updated successfully' });
}

async function deleteApplication(applicationId, userId, isAdminUser) {
    // Проверяем существование и права
    const checkQuery = `
        DECLARE $id AS Utf8;
        SELECT user_id FROM applications WHERE id = $id
    `;
    const checkResult = await ydb.execute(checkQuery, { $id: applicationId });

    if (checkResult.length === 0) {
        return errorResponse(404, 'Application not found');
    }

    if (!isAdminUser && checkResult[0].user_id !== userId) {
        return errorResponse(403, 'Access denied');
    }

    const query = `
        DECLARE $id AS Utf8;
        DELETE FROM applications WHERE id = $id
    `;
    await ydb.apply(query, { $id: applicationId });
    return successResponse(204, null);
}

async function searchApplications(filters, userId, isAdminUser, limit = 50) {
    try {
        // Проверяем подключение к YDB
        if (!ydb) {
            console.error('YDB client not initialized');
            return errorResponse(500, 'Database connection error');
        }

        console.log('Search request with filters:', JSON.stringify(filters));

        // ВАЖНО: Для продакшена следует использовать type-специфичные динамичные запросы.
        // Текущая реализация демонстрирует принцип, но требует усиления типизации.
        const items = [];
        console.log('Search completed, found items:', items.length);
        return successResponse(200, items);
    } catch (err) {
        console.error('Search error:', err);
        return errorResponse(500, 'Search failed: ' + err.message);
    }
}

// === Главный обработчик ===
exports.handler = async (event) => {
    try {
        if (!ydb) {
            return errorResponse(500, 'Database connection not initialized');
        }

        let body = {};
        if (event.body) {
            try {
                body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
            } catch (parseErr) {
                return errorResponse(400, 'Invalid JSON body');
            }
        }

        const httpMethod = event.httpMethod || 'GET';
        // Для локального тестирования проверяем event.resource или event.path
        let resource = event.resource || event.path;
        if (!resource) {
            // Fallback для простых тестовых вызовов
            if (httpMethod === 'POST' && (!event.path || event.path === '/api/applications')) resource = '/api/applications';
            else if (httpMethod === 'GET' && event.path && event.path.includes('/api/applications/') && event.path !== '/api/applications') resource = '/api/applications/{applicationId}';
            else if (httpMethod === 'PUT' && event.path && event.path.includes('/api/applications/')) resource = '/api/applications/{applicationId}';
            else if (httpMethod === 'DELETE' && event.path && event.path.includes('/api/applications/')) resource = '/api/applications/{applicationId}';
            else if (httpMethod === 'GET') resource = '/api/applications';
            else resource = '/api/applications';
        }

        const path = event.path || '';
        const queryParams = event.queryStringParameters || {};

        let token = event.headers?.Authorization || event.headers?.authorization;
        if (token && token.startsWith('Bearer ')) {
            token = token.slice(7);
        }

        let userId = null;
        let isAdminUser = false;
        if (token) {
            userId = getUserIdFromToken(token);
            isAdminUser = isAdmin(token);
        }

        if (httpMethod === 'OPTIONS') {
            return successResponse(200, {});
        }

        // Маршрутизация
        if (resource === '/api/applications' && httpMethod === 'GET') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            return await getApplications(userId, queryParams);
        }

        if (resource === '/api/applications' && httpMethod === 'POST') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            return await createApplication(body, userId);
        }

        if (resource === '/api/applications/{applicationId}' && httpMethod === 'GET') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            const applicationId = path.split('/').pop();
            if (!applicationId || applicationId === 'applications') return errorResponse(400, 'Invalid application ID');
            return await getApplicationById(applicationId, userId, isAdminUser);
        }

        if (resource === '/api/applications/{applicationId}' && httpMethod === 'PUT') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            const applicationId = path.split('/').pop();
            if (!applicationId || applicationId === 'applications') return errorResponse(400, 'Invalid application ID');
            return await updateApplication(applicationId, body, userId, isAdminUser);
        }

        if (resource === '/api/applications/{applicationId}' && httpMethod === 'DELETE') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            const applicationId = path.split('/').pop();
            if (!applicationId || applicationId === 'applications') return errorResponse(400, 'Invalid application ID');
            return await deleteApplication(applicationId, userId, isAdminUser);
        }

        if (resource === '/api/applications/search' && httpMethod === 'POST') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            const filters = body.filters || {};
            const limit = body.limit || 50;
            return await searchApplications(filters, userId, isAdminUser, limit);
        }

        if (resource === '/api/users/me' && httpMethod === 'GET') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            return successResponse(200, { userId, message: 'User profile endpoint (stub)' });
        }

        if (resource === '/api/users/me' && httpMethod === 'PUT') {
            if (!userId) return errorResponse(401, 'Unauthorized');
            return successResponse(200, { message: 'Profile updated (stub)' });
        }

        if (resource === '/admin/users' && httpMethod === 'GET') {
            if (!isAdminUser) return errorResponse(403, 'Admin access required');
            return successResponse(200, { message: 'Admin users list (stub)' });
        }

        if (resource === '/admin/audit' && httpMethod === 'GET') {
            if (!isAdminUser) return errorResponse(403, 'Admin access required');
            return successResponse(200, { message: 'Audit logs (stub)' });
        }

        return errorResponse(404, `Endpoint not found: ${httpMethod} ${resource}`);
    } catch (err) {
        console.error('CRITICAL ERROR:', err);
        return errorResponse(500, 'Internal server error');
    }
};